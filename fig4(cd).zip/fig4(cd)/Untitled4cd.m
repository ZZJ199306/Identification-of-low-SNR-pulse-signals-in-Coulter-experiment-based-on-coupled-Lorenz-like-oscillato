clc;clear
close all

%% 3
load('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig4(cd)\Test4cd.mat');
figure;
plot(Data1_time_AI_1_FIR_Filter,Data1_AI_1_FIR_Filter,'k','linewidth',2)
axis on
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
xlabel('Time(S)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');
ylabel('Amplitude(V)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');

figure;
A=3.67205;
B=0.01/150;
r=3.8*10^(-3);
tspan=[0:0.000001:4];
P=r*exp(-((tspan-A)/B).^2)+0.02088;
plot(tspan,P,'r','linewidth',2)
hold on
plot(Data1_time_AI_1_FIR_Filter,Data1_AI_1_FIR_Filter,'k','linewidth',2)
axis([3.6714 3.6726 0.0202 0.025])
axis on
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
xlabel('Time(S)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');
ylabel('Amplitude(V)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');


