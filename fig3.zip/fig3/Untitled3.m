clc;clear
close all
%% ԭʼ�źŲ��ַ���һ
figure;
load('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig3\Test3.mat');
Average_1=mean(Data1_AI_8);
plot(Data1_time_AI_8,Data1_AI_8,'k','linewidth',1)
hold on
Time=[0 Data1_time_AI_8(end)];
Average=[Average_1,Average_1];
plot(Time,Average,'b','linewidth',2)
axis([0 Data1_time_AI_8(end) 0.054 0.066])
axis on
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
xlabel('Time(S)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');
ylabel('Amplitude(V)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');
%% ����Ҷ���� ��Ƶͼ
figure;
step=1/100000;
N=length(Data1_AI_8);
n=1:N;                                        
f=n/(N*step);                                             
Data1_AI_8=Data1_AI_8-mean(Data1_AI_8);
Z1=fft(Data1_AI_8);
semilogx(f,abs(Z1)*2/N,'k-','linewidth',2)
axis on
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
ylabel('\mid FFT coefficient \mid','FontSize',20,'Fontname','Times New Roman','FontWeight','bold')
xlabel('Frequency(Hz)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold')
axis([10^(-2) 1*10^(5) 0 1.2*10^(-3)])