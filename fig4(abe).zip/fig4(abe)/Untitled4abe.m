clc;clear
close all
%% 1
figure;
load('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig4(abe)\Test4ab.mat');
plot(Data1_time_AI_1,Data1_AI_1,'k','linewidth',2)
axis([0 7 0.05 0.075])
hold on
Time=[0 Data1_time_AI_1(end)];
Average=[mean(Data1_AI_1),mean(Data1_AI_1)];
axis on
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
xlabel('Time(S)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');
ylabel('Amplitude(V)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');

figure;
plot(Data1_time_AI_1,Data1_AI_1,'k','linewidth',2)
axis([3.6708 3.673 0.056 0.07])
axis on
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
xlabel('Time(S)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');
ylabel('Amplitude(V)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold');

figure;
step=1/100000;
N=length(Data1_AI_1);
n=1:N;
f=n/(N*step);                                        
Data1_AI_1=Data1_AI_1-mean(Data1_AI_1);
Z1=fft(Data1_AI_1);
semilogx(f,abs(Z1)*2/N,'k-','linewidth',2)
axis on
axis([10^-2 10^5 0 2*10^-3])
set(gca,'FontSize',15,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
ylabel('\mid FFT coefficient \mid','FontSize',20,'Fontname','Times New Roman','FontWeight','bold')
xlabel('Frequency(Hz)','FontSize',20,'Fontname','Times New Roman','FontWeight','bold')
