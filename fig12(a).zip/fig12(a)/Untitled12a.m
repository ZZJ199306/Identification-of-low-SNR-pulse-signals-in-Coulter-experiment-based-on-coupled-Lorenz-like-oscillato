clc;clear
close all
%% 1
figure;
load('C:\Users\Zhao Zhijie\Desktop\Thesis procedure\fig12(a)\Test12a.mat');
subplot(211)
plot(Data1_time_AI_8,Data1_AI_8,'r','linewidth',1)
axis on
set(gca,'FontSize',20,'Fontname','Times New Roman','FontWeight','bold','linewidth',2)
ylabel('Amplitude(V)','FontSize',25,'Fontname','Times New Roman','FontWeight','bold');

subplot(212)
plot(Data1_time_AI_1,Data1_AI_1,'k','linewidth',1)
set(gca,'FontSize',20,'Fontname', 'Times New Roman','FontWeight','bold');
xlabel('Time(S)','FontSize',25,'Fontname','Times New Roman','FontWeight','bold')
ylabel('Amplitude(V)','FontSize',25,'Fontname','Times New Roman','FontWeight','bold')